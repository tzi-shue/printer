cp rastertocapt /usr/lib/cups/filter/
chmod 755 /usr/lib/cups/filter/rastertocapt 
cp *.ppd /usr/share/cups/model/
